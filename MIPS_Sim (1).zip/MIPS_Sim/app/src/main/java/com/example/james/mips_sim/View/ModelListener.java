package com.example.james.mips_sim.View;

import com.example.james.mips_sim.Executor.DebugEvent;

public interface ModelListener {


    public void update(DebugEvent event);

    public void reset();


}